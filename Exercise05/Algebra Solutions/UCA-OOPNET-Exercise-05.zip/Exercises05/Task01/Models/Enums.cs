﻿namespace Task01.Models
{
	public enum PictureMode
	{
		Mark,
		Unmark
	}
}
